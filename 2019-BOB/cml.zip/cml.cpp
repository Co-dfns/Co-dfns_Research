#include <time.h>
#include <stdint.h>
#include <inttypes.h>
#include <limits.h>
#include <float.h>
#include <locale>
#include <codecvt>
#include <math.h>
#include <memory>
#include <algorithm>
#include <stack>
#include <string>
#include <cstring>
#include <vector>
#include <unordered_map>
#include <arrayfire.h>
using namespace af;

#if AF_API_VERSION < 36
#error "Your ArrayFire version is too old."
#endif
#ifdef _WIN32
 #define EXPORT extern "C" __declspec(dllexport)
#elif defined(__GNUC__)
 #define EXPORT extern "C" __attribute__ ((visibility ("default")))
#else
 #define EXPORT extern "C"
#endif
#ifdef _MSC_VER
 #define RSTCT __restrict
#else
 #define RSTCT restrict
#endif
#define S struct
#define Z static
#define R return
#define this_c *this
#define RANK(lp) ((lp)->p->r)
#define TYPE(lp) ((lp)->p->t)
#define SHAPE(lp) ((lp)->p->s)
#define ETYPE(lp) ((lp)->p->e)
#define DATA(lp) ((V*)&SHAPE(lp)[RANK(lp)])
#define CS(n,x) case n:x;break;
#define DO(n,x) {I i=0,_i=(n);for(;i<_i;++i){x;}}
#define DOB(n,x) {B i=0,_i=(n);for(;i<_i;++i){x;}}
#define NM(n,nm,sm,sd,di,mf,df,ma,da) S n##_f:FN{di;mf;df;ma;da;\
 n##_f():FN(nm,sm,sd){}};
#define OM(n,nm,sm,sd,mf,df) S n##_o:MOP{mf;df;\
 n##_o(FN&l):MOP(nm,sm,sd,l){}};\
 S n##_k:MOK{V operator()(FN*&f,FN&l){f=new n##_o(l);}};
#define OD(n,nm,sm,sd,mf,df) S n##_o:DOP{mf;df;\
 n##_o(FN&l,FN&r):DOP(nm,sm,sd,l,r){}\
 n##_o(const A&l,FN&r):DOP(nm,sm,sd,l,r){}\
 n##_o(FN&l,const A&r):DOP(nm,sm,sd,l,r){}};\
 S n##_k:DOK{V operator()(FN*&f,FN&l,FN&r){f=new n##_o(l,r);}\
  V operator()(FN*&f,const A&l,FN&r){f=new n##_o(l,r);}\
  V operator()(FN*&f,FN&l,const A&r){f=new n##_o(l,r);}};
#define MT
#define DID inline array id(dim4)
#define MFD inline V operator()(A&,const A&,ENV&)
#define MAD inline V operator()(A&,const A&,D,ENV&)
#define DFD inline V operator()(A&,const A&,const A&,ENV&)
#define DAD inline V operator()(A&,const A&,const A&,D,ENV&)
#define DI(n) inline array n::id(dim4 s)
#define ID(n,x,t) DI(n##_f){R constant(x,s,t);}
#define MF(n) inline V n::operator()(A&z,const A&r,ENV&e)
#define MA(n) inline V n::operator()(A&z,const A&r,D ax,ENV&e)
#define DF(n) inline V n::operator()(A&z,const A&l,const A&r,ENV&e)
#define DA(n) inline V n::operator()(A&z,const A&l,const A&r,D ax,ENV&e)
#define SF(n,x) inline V n::operator()(A&z,const A&l,const A&r,ENV&e){\
 if(l.r==r.r&&l.s==r.s){\
  z.r=l.r;z.s=l.s;const array&lv=l.v;const array&rv=r.v;x;R;}\
 if(!l.r){\
  z.r=r.r;z.s=r.s;const array&rv=r.v;array lv=tile(l.v,r.s);x;R;}\
 if(!r.r){\
  z.r=l.r;z.s=l.s;array rv=tile(r.v,l.s);const array&lv=l.v;x;R;}\
 if(l.r!=r.r)err(4);if(l.s!=r.s)err(5);err(99);}
#define PUSH(x) s.emplace(BX(x))
#define POP(f,x) x=s.top().f;s.pop()
#define EX(x) delete x
#define EF(init,ex,fun) EXPORT V ex##_dwa(lp*z,lp*l,lp*r){try{\
  A cl,cr,za;fn##init##_c(za,cl,cr,e##init);\
  cpda(cr,r);cpda(cl,l);(*(*e##init[0])[fun].f)(za,cl,cr,e##init);cpad(z,za);}\
 catch(U n){derr(n);}\
 catch(exception e){msg=mkstr(e.what());dmx.e=msg.c_str();derr(500);}}\
EXPORT V ex##_cdf(A*z,A*l,A*r){(*(*e##init[0])[fun].f)(*z,*l,*r,e##init);}
#define EV(init,ex,slt)
typedef enum{APLNC=0,APLU8,APLTI,APLSI,APLI,APLD,APLP,APLU,APLV,APLW,APLZ,
 APLR,APLF,APLQ}APLTYPE;
typedef long long L;typedef int I;typedef int16_t S16;typedef int8_t S8;
typedef double D;typedef unsigned char U8;typedef unsigned U;
typedef dim_t B;typedef cdouble DZ;typedef void V;typedef std::string STR;
S{U f=3;U n;U x=0;const wchar_t*v=L"Co-dfns";const wchar_t*e;V*c;}dmx;
S lp{S{L l;B c;U t:4;U r:4;U e:4;U _:13;U _1:16;U _2:16;B s[1];}*p;};
S dwa{B z;S{B z;V*(*ga)(U,U,B*,S lp*);V(*p[16])();V(*er)(V*);}*ws;V*p[4];};
S dwa*dwafns;Z V derr(U n){dmx.n=n;dwafns->ws->er(&dmx);}
EXPORT I DyalogGetInterpreterFunctions(dwa*p){
 if(p)dwafns=p;else R 0;if(dwafns->z<sizeof(S dwa))R 16;R 0;}
Z V err(U n,wchar_t*e){dmx.e=e;throw n;}Z V err(U n){dmx.e=L"";throw n;}
dim4 eshp=dim4(0,(B*)NULL);
std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> strconv;
std::wstring msg;S BX;
typedef std::vector<BX> FRM;typedef std::vector<FRM*> ENV;
typedef std::stack<BX> STK;
S A{I r,f;dim4 s;array v;std::vector<A> nv;
 A(I r,dim4 s,array v):r(r),f(1),s(s),v(v){}
 A():r(0),f(0),s(dim4()),v(array()){}};
S FN{STR nm;I sm;I sd;FN(STR nm,I sm,I sd):nm(nm),sm(sm),sd(sd){}
 FN():nm(""),sm(0),sd(0){}
 virtual array id(dim4 s){err(16);R array();}
 virtual V operator()(A&z,const A&r,ENV&e){err(99);}
 virtual V operator()(A&z,const A&r,D ax,ENV&e){err(99);}
 virtual V operator()(A&z,const A&l,const A&r,ENV&e){err(99);}
 virtual V operator()(A&z,const A&l,const A&r,D ax,ENV&e){err(99);}};
FN MTFN;
S MOP:FN{FN&ll;
 MOP(STR nm,I sm,I sd,FN&ll):FN(nm,sm,sd),ll(ll){}};
S DOP:FN{I fl;I fr;FN&ll;A aa;FN&rr;A ww;
 DOP(STR nm,I sm,I sd,FN&l,FN&r)
  :FN(nm,sm,sd),fl(1),fr(1),ll(l),aa(A()),rr(r),ww(A()){}
 DOP(STR nm,I sm,I sd,A l,FN&r)
  :FN(nm,sm,sd),fl(0),fr(1),ll(MTFN),aa(l),rr(r),ww(A()){}
 DOP(STR nm,I sm,I sd,FN&l,A r)
  :FN(nm,sm,sd),fl(1),fr(0),ll(l),aa(A()),rr(MTFN),ww(r){}};
S MOK{virtual V operator()(FN*&f,FN&l){err(99);}};
S DOK{virtual V operator()(FN*&f,FN&l,FN&r){err(99);}
 virtual V operator()(FN*&f,const A&l,FN&r){err(99);}
 virtual V operator()(FN*&f,FN&l,const A&r){err(99);}};
S BX{A v;union{FN*f;MOK*m;DOK*d;};
 BX(){}BX(FN*f):f(f){}BX(const A&v):v(v){}BX(MOK*m):m(m){}BX(DOK*d):d(d){}};

std::wstring mkstr(const char*s){R strconv.from_bytes(s);}
I scm(FN&f){R f.sm;}I scm(const A&a){R 1;}
I scd(FN&f){R f.sd;}I scd(const A&a){R 1;}
B cnt(dim4 s){B c=1;DO(4,c*=s[i]);R c;}
B cnt(const A&a){B c=1;DO(a.r,c*=a.s[i]);R c;}
B cnt(lp*d){B c=1;DO(RANK(d),c*=SHAPE(d)[i]);R c;}
array scl(D x){R constant(x,dim4(1),f64);}
array scl(I x){R constant(x,dim4(1),s32);}
A scl(array v){R A(0,dim4(1),v);}
dtype mxt(dtype at,dtype bt){if(at==c64||bt==c64)R c64;
 if(at==f64||bt==f64)R f64;
 if(at==s32||bt==s32)R s32;if(at==s16||bt==s16)R s16;
 if(at==b8||bt==b8)R b8;err(16);R f64;}
dtype mxt(const array&a,const array&b){R mxt(a.type(),b.type());}
dtype mxt(dtype at,const A&b){R mxt(at,b.v.type());}
Z array da16(B c,dim4 s,lp*d){std::vector<S16>b(c);
 S8*v=(S8*)DATA(d);DOB(c,b[i]=v[i]);R array(s,b.data());}
Z array da8(B c,dim4 s,lp*d){std::vector<char>b(c);
 U8*v=(U8*)DATA(d);DOB(c,b[i]=1&(v[i/8]>>(7-(i%8))))
 R array(s,b.data());}
V cpad(lp*d,A&a){I t;B c=cnt(a);if(!a.f){d->p=NULL;R;}
 switch(a.v.type()){CS(c64,t=APLZ);
  CS(s32,t=APLI);CS(s16,t=APLSI);CS(b8,t=APLTI);CS(f64,t=APLD);
  default:if(c)err(16);t=APLI;}
 B s[4];DO(a.r,s[a.r-(i+1)]=a.s[i]);dwafns->ws->ga(t,a.r,s,d);
 if(c)a.v.host(DATA(d));}
V cpda(A&a,lp*d){if(d==NULL)R;if(15!=TYPE(d))err(16);if(4<RANK(d))err(16);
 dim4 s(1);DO(RANK(d),s[RANK(d)-(i+1)]=SHAPE(d)[i]);B c=cnt(d);
 switch(ETYPE(d)){
  CS(APLZ,a=A(RANK(d),s,c?array(s,(DZ*)DATA(d)):scl(0)))
  CS(APLI,a=A(RANK(d),s,c?array(s,(I*)DATA(d)):scl(0)))
  CS(APLD,a=A(RANK(d),s,c?array(s,(D*)DATA(d)):scl(0)))
  CS(APLSI,a=A(RANK(d),s,c?array(s,(S16*)DATA(d)):scl(0)))
  CS(APLTI,a=A(RANK(d),s,c?da16(c,s,d):scl(0)))
  CS(APLU8,a=A(RANK(d),s,c?da8(c,s,d):scl(0)))
  default:err(16);}}
EXPORT A*mkarray(lp*d){A*z=new A;cpda(*z,d);R z;}
EXPORT V frea(A*a){delete a;}
EXPORT V exarray(lp*d,A*a){cpad(d,*a);}
EXPORT V afsync(){sync();}
EXPORT Window *w_new(char *k){R new Window(k);}
EXPORT I w_close(Window*w){R w->close();}
EXPORT V w_del(Window*w){delete w;}
EXPORT V w_img(lp*d,Window*w){A a;cpda(a,d);
 w->image(a.v.as(a.r==2?f32:u8));}
EXPORT V w_plot(lp*d,Window*w){A a;cpda(a,d);w->plot(a.v.as(f32));}
EXPORT V w_hist(lp*d,D l,D h,Window*w){A a;cpda(a,d);
 w->hist(a.v.as(u32),l,h);}
EXPORT V loadimg(lp*z,char*p,I c){array a=loadImage(p,c);
 A b(a.numdims(),a.dims(),a.as(s16));cpad(z,b);}
EXPORT V saveimg(lp*im,char*p){A a;cpda(a,im);
 saveImageNative(p,a.v.as(a.v.type()==s32?u16:u8));}
EXPORT V cd_sync(V){sync();}
NM(sub,"sub",1,1,DID,MFD,DFD,MT ,MT )
sub_f sub_c;
ID(sub,0,s32)
MF(sub_f){z.r=r.r;z.s=r.s;z.v=-r.v;}
SF(sub_f,z.v=lv-rv)

NM(mul,"mul",1,1,DID,MFD,DFD,MT ,MT )
mul_f mul_c;
ID(mul,1,s32)
MF(mul_f){z.r=r.r;z.s=r.s;z.v=(r.v>0)-(r.v<0);}
SF(mul_f,z.v=lv*rv)

NM(lth,"lth",1,1,DID,MT ,DFD,MT ,MT )
lth_f lth_c;
ID(lth,0,s32)
SF(lth_f,z.v=lv<rv)

NM(lte,"lte",1,1,DID,MT ,DFD,MT ,MT )
lte_f lte_c;
ID(lte,1,s32)
SF(lte_f,z.v=lv<=rv)

NM(gte,"gte",1,1,DID,MT ,DFD,MT ,MT )
gte_f gte_c;
ID(gte,1,s32)
SF(gte_f,z.v=lv>=rv)

NM(lor,"lor",1,1,DID,MT ,DFD,MT ,MT )
lor_f lor_c;
ID(lor,0,s32)
SF(lor_f,if(rv.isbool()&&lv.isbool())z.v=lv||rv;
 else if(lv.isbool()&&rv.isinteger())z.v=lv+(!lv)*abs(rv).as(rv.type());
 else if(rv.isbool()&&lv.isinteger())z.v=rv+(!rv)*abs(lv).as(lv.type());
 else if(lv.isinteger()&&rv.isinteger()){B c=cnt(z);
  std::vector<I> a(c);abs(lv).as(s32).host(a.data());
  std::vector<I> b(c);abs(rv).as(s32).host(b.data());
  DOB(c,while(b[i]){I t=b[i];b[i]=a[i]%b[i];a[i]=t;})
  z.v=array(z.s,a.data());}
 else{B c=cnt(z);
  std::vector<D> a(c);abs(lv).as(f64).host(a.data());
  std::vector<D> b(c);abs(rv).as(f64).host(b.data());
  DOB(c,while(b[i]>1e-12){D t=b[i];b[i]=fmod(a[i],b[i]);a[i]=t;})
  z.v=array(z.s,a.data());})

NM(and,"and",1,1,DID,MT,DFD,MT,MT)
and_f and_c;
ID(and,1,s32)
SF(and_f,if(lv.isbool()&&rv.isbool())z.v=lv&&rv;
 else if(allTrue<I>(lv>=0&&lv<=1&&rv>0&&rv<=1))z.v=lv&&rv;
 else{A a(z.r,z.s,lv);A b(z.r,z.s,rv);
  lor_c(a,a,b,e);z.v=lv*(rv/((!a.v)+a.v));})
NM(cat,"cat",0,0,MT ,MFD,DFD,MT ,DAD)
cat_f cat_c;
MF(cat_f){z.r=1;z.s[0]=cnt(r);z.v=flat(r.v);}
DA(cat_f){A nl=l,nr=r;I fx=(I)ceil(ax);
 if(fx<0||(fx>r.r&&fx>l.r))err(4);
 if(ax!=fx){if(r.r>3||l.r>3)err(10);
  if(nl.r){nl.r++;DO(3-fx,nl.s[3-i]=nl.s[3-(i+1)]);nl.s[fx]=1;}
  if(nr.r){nr.r++;DO(3-fx,nr.s[3-i]=nr.s[3-(i+1)]);nr.s[fx]=1;}
  if(nl.r)nl.v=moddims(nl.v,nl.s);if(nr.r)nr.v=moddims(nr.v,nr.s);
  cat_c(z,nl,nr,fx,e);R;}
 if(fx>=r.r&&fx>=l.r)err(4);
 if(l.r&&r.r&&std::abs((I)l.r-(I)r.r)>1)err(4);
 z.r=(l.r>=r.r)*l.r+(r.r>l.r)*r.r+(!r.r&&!l.r);
 dim4 ls=l.s;dim4 rs=r.s;
 if(!l.r){ls=rs;ls[fx]=1;}if(!r.r){rs=ls;rs[fx]=1;}
 if(r.r&&l.r>r.r){DO(3-fx,rs[3-i]=rs[3-(i+1)]);rs[fx]=1;}
 if(l.r&&r.r>l.r){DO(3-fx,ls[3-i]=ls[3-(i+1)]);ls[fx]=1;}
 DO(4,if(i!=fx&&rs[i]!=ls[i])err(5));
 DO(4,z.s[i]=(l.r>=r.r||i==fx)*ls[i]+(r.r>l.r||i==fx)*rs[i]);
 if(!cnt(l)){z.v=r.v;R;}if(!cnt(r)){z.v=l.v;R;}
 dtype mt=mxt(r.v,l.v);
 array lv=(l.r?moddims(l.v,ls):tile(l.v,ls)).as(mt);
 array rv=(r.r?moddims(r.v,rs):tile(r.v,rs)).as(mt);
 z.v=join(fx,lv,rv);}
DF(cat_f){if(l.r||r.r){cat_c(z,l,r,0,e);R;}
 A a,b;cat_c(a,l,e);cat_c(b,r,e);cat_c(z,a,b,0,e);}
OM(map,"map",1,1,MFD,DFD)
MF(map_o){if(scm(ll)){ll(z,r,e);R;}
 z.r=r.r;z.s=r.s;I c=(I)cnt(z);if(!c){z.v=scl(0);R;}
 A zs;A rs=scl(r.v(0));ll(zs,rs,e);if(c==1){z.v=zs.v;R;}
 array v=array(z.s,zs.v.type());v(0)=zs.v(0);
 DO(c-1,rs.v=r.v(i+1);ll(zs,rs,e);v(i+1)=zs.v(0))z.v=v;}
DF(map_o){if(scd(ll)){ll(z,l,r,e);R;}
 if((l.r==r.r&&l.s==r.s)||!l.r){z.r=r.r;z.s=r.s;}
 else if(!r.r){z.r=l.r;z.s=l.s;}else if(l.r!=r.r)err(4);
 else if(l.s!=r.s)err(5);else err(99);I c=(I)cnt(z);
 if(!c){z.v=scl(0);R;}A zs;A rs=scl(r.v(0));A ls=scl(l.v(0));
 ll(zs,ls,rs,e);if(c==1){z.v=zs.v;R;}
 array v=array(z.s,zs.v.type());v(0)=zs.v(0);
 if(!r.r){rs.v=r.v;
  DO(c-1,ls.v=l.v(i+1);ll(zs,ls,rs,e);v(i+1)=zs.v(0);)
  z.v=v;R;}
 if(!l.r){ls.v=l.v;
  DO(c-1,rs.v=r.v(i+1);ll(zs,ls,rs,e);v(i+1)=zs.v(0);)
  z.v=v;R;}
 DO(c-1,ls.v=l.v(i+1);rs.v=r.v(i+1);ll(zs,ls,rs,e);
  v(i+1)=zs.v(0))z.v=v;}
NM(rdf,"rdf",0,0,DID,MT ,DFD,MT ,MT )
ID(rdf,1,s32)
OM(rdf,"rdf",0,0,MFD,DFD)
rdf_f rdf_c;
DF(rdf_f){if(l.r>1)err(4);I ra=r.r?r.r-1:0;z.r=ra+1;z.s=r.s;
 if(l.r!=0&&l.s[0]!=1&&r.r!=0&&r.s[ra]!=1&&l.s[0]!=r.s[ra])err(5);
 array x=l.v;array y=r.v;if(cnt(l)==1)x=tile(x,(I)r.s[ra]);
 if(r.s[ra]==1){dim4 s(1);s[ra]=cnt(l);y=tile(y,s);}
 z.s[ra]=sum<B>(abs(x));if(!cnt(z)){z.v=scl(0);R;}
 array w=where(x).as(s32);af::index ix[4];if(z.s[ra]==w.elements()){
  ix[ra]=w;z.v=y(ix[0],ix[1],ix[2],ix[3]);R;}
 array i=shift(accum(abs(x(w))),1),d=shift(w,1);i(0)=0;d(0)=0;
 array v=array(z.s[ra],s32),u=array(z.s[ra],s32);v=0;u=0;
 array s=(!sign(x(w))).as(s32);array t=shift(s,1);t(0)=0;
 v(i)=w-d;u(i)=s-t;ix[ra]=accum(v);z.v=y(ix[0],ix[1],ix[2],ix[3]);
 dim4 s1(1),s2(z.s);s1[ra]=z.s[ra];s2[ra]=1;u=array(accum(u),s1);
 z.v*=tile(u,(I)s2[0],(I)s2[1],(I)s2[2],(I)s2[3]);}
MF(rdf_o){A t(r.r?r.r-1:0,dim4(1),r.v(0));DO(t.r,t.s[i]=r.s[i])
 I rc=(I)r.s[t.r];I zc=(I)cnt(t);map_o mfn_c(ll);
 if(!zc){t.v=scl(0);z=t;R;}if(!rc){t.v=ll.id(t.s);z=t;R;}
 if(1==rc){t.v=array(r.v,t.s);z=t;R;}
 if("add"==ll.nm){if(r.v.isbool())t.v=count(r.v,t.r).as(s32);
  else t.v=sum(r.v.as(f64),t.r);z=t;R;}
 if("mul"==ll.nm){t.v=product(r.v.as(f64),t.r);z=t;R;}
 if("min"==ll.nm){t.v=min(r.v,t.r);z=t;R;}
 if("max"==ll.nm){t.v=max(r.v,t.r);z=t;R;}
 if("and"==ll.nm){t.v=allTrue(r.v,t.r);z=t;R;}
 if("lor"==ll.nm){t.v=anyTrue(r.v,t.r);z=t;R;}
 af::index x[4];x[t.r]=rc-1;t.v=r.v(x[0],x[1],x[2],x[3]);
 DO(rc-1,x[t.r]=rc-(i+2);
  mfn_c(t,A(t.r,t.s,r.v(x[0],x[1],x[2],x[3])),t,e));z=t;}
DF(rdf_o){if(l.r!=0&&(l.r!=1||l.s[0]!=1))err(5);if(!r.r)err(4);
 I lv=l.v.as(s32).scalar<I>();I ra=r.r-1;
  if((r.s[ra]+1)<lv)err(5);I rc=(I)((1+r.s[ra])-abs(lv));
 map_o mfn_c(ll);A t(r.r,r.s,scl(0));t.s[ra]=rc;if(!cnt(t)){z=t;R;}
 if(!lv){t.v=ll.id(t.s);z=t;R;}seq rng(rc);af::index x[4];
 if(lv>=0){x[ra]=rng+((D)lv-1);t.v=r.v(x[0],x[1],x[2],x[3]);
  DO(lv-1,x[ra]=rng+((D)lv-(i+2));
   mfn_c(t,A(t.r,t.s,r.v(x[0],x[1],x[2],x[3])),t,e))
 }else{x[ra]=rng;t.v=r.v(x[0],x[1],x[2],x[3]);
  DO(abs(lv)-1,x[ra]=rng+(D)(i+1);
   mfn_c(t,A(t.r,t.s,r.v(x[0],x[1],x[2],x[3])),t,e))}
 z=t;}

S fn0_f:FN{MFD;DFD;fn0_f():FN("fnfn0",0,0){};};
fn0_f fn0_c;MF(fn0_f){fn0_c(z,A(),r,e);}
S fn56_f:FN{MFD;DFD;fn56_f():FN("fnfn56",0,0){};};
fn56_f fn56_c;MF(fn56_f){fn56_c(z,A(),r,e);}

ENV e0(1);I is0=0;
DF(fn0_f){if(is0)R;I fd=0;STK s;e[0]=new FRM(1);
 PUSH(&fn56_c);
 (*e[fd])[0]=s.top();
 s.pop();
 is0=1;}


DF(fn56_f){FRM*of=NULL;I fd=1;try{STK s;
FRM f(2);if(e.size()<=fd)e.resize(fd+1);of=e[fd];e[fd]=&f;
 PUSH(r);
 PUSH(&gte_c);
 PUSH(scl(scl(122)));
 {A z,x,y;FN*f;POP(v,x);POP(f,f);POP(v,y);(*f)(z,x,y,e);PUSH(z);}
 PUSH(&and_c);
 PUSH(r);
 PUSH(&lte_c);
 PUSH(scl(scl(97)));
 {A z,x,y;FN*f;POP(v,x);POP(f,f);POP(v,y);(*f)(z,x,y,e);PUSH(z);}
 {A z,x,y;FN*f;POP(v,x);POP(f,f);POP(v,y);(*f)(z,x,y,e);PUSH(z);}
 (*e[fd])[0]=s.top();
 PUSH(&lor_c);
 PUSH(r);
 PUSH(&gte_c);
 PUSH(scl(scl(90)));
 {A z,x,y;FN*f;POP(v,x);POP(f,f);POP(v,y);(*f)(z,x,y,e);PUSH(z);}
 PUSH(&and_c);
 PUSH(r);
 PUSH(&lte_c);
 PUSH(scl(scl(65)));
 {A z,x,y;FN*f;POP(v,x);POP(f,f);POP(v,y);(*f)(z,x,y,e);PUSH(z);}
 {A z,x,y;FN*f;POP(v,x);POP(f,f);POP(v,y);(*f)(z,x,y,e);PUSH(z);}
 {A z,x,y;FN*f;POP(v,x);POP(f,f);POP(v,y);(*f)(z,x,y,e);PUSH(z);}
 (*e[fd])[1]=s.top();
 PUSH(&lth_c);
 PUSH(new rdf_k());
 {FN*f,*g;MOK*o;POP(m,o);POP(f,g);(*o)(f,*g);EX(o);PUSH(f);}
 PUSH(scl(scl(2)));
 {A z,x,y;FN*f;POP(v,x);POP(f,f);POP(v,y);(*f)(z,x,y,e);PUSH(z);}
 PUSH(&cat_c);
 PUSH(scl(scl(1)));
 {A z,x,y;FN*f;POP(v,x);POP(f,f);POP(v,y);(*f)(z,x,y,e);PUSH(z);}
 PUSH(&and_c);
 PUSH((*e[1])[0].v);
 {A z,x,y;FN*f;POP(v,x);POP(f,f);POP(v,y);(*f)(z,x,y,e);PUSH(z);}
 PUSH(&mul_c);
 PUSH(scl(scl(32)));
 {A z,x,y;FN*f;POP(v,x);POP(f,f);POP(v,y);(*f)(z,x,y,e);PUSH(z);}
 PUSH(&sub_c);
 PUSH(r);
 {A z,x,y;FN*f;POP(v,x);POP(f,f);POP(v,y);(*f)(z,x,y,e);PUSH(z);}
 PUSH(&rdf_c);
 PUSH((*e[1])[1].v);
 {A z,x,y;FN*f;POP(v,x);POP(f,f);POP(v,y);(*f)(z,x,y,e);PUSH(z);}
 POP(v,z);z.f=1;e[fd]=of;R;
 }catch(U x){e[fd]=of;throw x;}
 catch(exception x){e[fd]=of;throw x;}}
EF(0,scl,0)
