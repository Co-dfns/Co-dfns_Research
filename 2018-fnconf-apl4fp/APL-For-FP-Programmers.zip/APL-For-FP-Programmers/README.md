# APL-For-FP-Programmers
