#include <time.h>
#include <stdint.h>
#include <inttypes.h>
#include <limits.h>
#include <float.h>
#include <locale>
#include <codecvt>
#include <math.h>
#include <memory>
#include <algorithm>
#include <stack>
#include <string>
#include <cstring>
#include <vector>
#include <unordered_map>
#include <arrayfire.h>
using namespace af;

#if AF_API_VERSION < 36
#error "Your ArrayFire version is too old."
#endif
#ifdef _WIN32
 #define EXPORT extern "C" __declspec(dllexport)
#elif defined(__GNUC__)
 #define EXPORT extern "C" __attribute__ ((visibility ("default")))
#else
 #define EXPORT extern "C"
#endif
#ifdef _MSC_VER
 #define RSTCT __restrict
#else
 #define RSTCT restrict
#endif
#define S struct
#define Z static
#define R return
#define this_c *this
#define RANK(lp) ((lp)->p->r)
#define TYPE(lp) ((lp)->p->t)
#define SHAPE(lp) ((lp)->p->s)
#define ETYPE(lp) ((lp)->p->e)
#define DATA(lp) ((V*)&SHAPE(lp)[RANK(lp)])
#define CS(n,x) case n:x;break;
#define DO(n,x) {I i=0,_i=(n);for(;i<_i;++i){x;}}
#define DOB(n,x) {B i=0,_i=(n);for(;i<_i;++i){x;}}
#define NM(n,nm,sm,sd,di,mf,df,ma,da) S n##_f:FN{di;mf;df;ma;da;\
 n##_f():FN(nm,sm,sd){}};
#define OM(n,nm,sm,sd,mf,df) S n##_o:MOP{mf;df;\
 n##_o(FN&l):MOP(nm,sm,sd,l){}};\
 S n##_k:MOK{V operator()(FN*&f,FN&l){f=new n##_o(l);}};
#define OD(n,nm,sm,sd,mf,df) S n##_o:DOP{mf;df;\
 n##_o(FN&l,FN&r):DOP(nm,sm,sd,l,r){}\
 n##_o(const A&l,FN&r):DOP(nm,sm,sd,l,r){}\
 n##_o(FN&l,const A&r):DOP(nm,sm,sd,l,r){}};\
 S n##_k:DOK{V operator()(FN*&f,FN&l,FN&r){f=new n##_o(l,r);}\
  V operator()(FN*&f,const A&l,FN&r){f=new n##_o(l,r);}\
  V operator()(FN*&f,FN&l,const A&r){f=new n##_o(l,r);}};
#define MT
#define DID inline array id(dim4)
#define MFD inline V operator()(A&,const A&,ENV&)
#define MAD inline V operator()(A&,const A&,D,ENV&)
#define DFD inline V operator()(A&,const A&,const A&,ENV&)
#define DAD inline V operator()(A&,const A&,const A&,D,ENV&)
#define DI(n) inline array n::id(dim4 s)
#define ID(n,x,t) DI(n##_f){R constant(x,s,t);}
#define MF(n) inline V n::operator()(A&z,const A&r,ENV&e)
#define MA(n) inline V n::operator()(A&z,const A&r,D ax,ENV&e)
#define DF(n) inline V n::operator()(A&z,const A&l,const A&r,ENV&e)
#define DA(n) inline V n::operator()(A&z,const A&l,const A&r,D ax,ENV&e)
#define SF(n,x) inline V n::operator()(A&z,const A&l,const A&r,ENV&e){\
 if(l.r==r.r&&l.s==r.s){\
  z.r=l.r;z.s=l.s;const array&lv=l.v;const array&rv=r.v;x;R;}\
 if(!l.r){\
  z.r=r.r;z.s=r.s;const array&rv=r.v;array lv=tile(l.v,r.s);x;R;}\
 if(!r.r){\
  z.r=l.r;z.s=l.s;array rv=tile(r.v,l.s);const array&lv=l.v;x;R;}\
 if(l.r!=r.r)err(4);if(l.s!=r.s)err(5);err(99);}
#define PUSH(x) s.emplace(BX(x))
#define POP(f,x) x=s.top().f;s.pop()
#define EX(x) delete x
#define EF(init,ex,fun) EXPORT V ex##_dwa(lp*z,lp*l,lp*r){try{\
  A cl,cr,za;fn##init##_c(za,cl,cr,e##init);\
  cpda(cr,r);cpda(cl,l);(*(*e##init[0])[fun].f)(za,cl,cr,e##init);cpad(z,za);}\
 catch(U n){derr(n);}\
 catch(exception e){msg=mkstr(e.what());dmx.e=msg.c_str();derr(500);}}\
EXPORT V ex##_cdf(A*z,A*l,A*r){(*(*e##init[0])[fun].f)(*z,*l,*r,e##init);}
#define EV(init,ex,slt)
typedef enum{APLNC=0,APLU8,APLTI,APLSI,APLI,APLD,APLP,APLU,APLV,APLW,APLZ,
 APLR,APLF,APLQ}APLTYPE;
typedef long long L;typedef int I;typedef int16_t S16;typedef int8_t S8;
typedef double D;typedef unsigned char U8;typedef unsigned U;
typedef dim_t B;typedef cdouble DZ;typedef void V;typedef std::string STR;
S{U f=3;U n;U x=0;const wchar_t*v=L"Co-dfns";const wchar_t*e;V*c;}dmx;
S lp{S{L l;B c;U t:4;U r:4;U e:4;U _:13;U _1:16;U _2:16;B s[1];}*p;};
S dwa{B z;S{B z;V*(*ga)(U,U,B*,S lp*);V(*p[16])();V(*er)(V*);}*ws;V*p[4];};
S dwa*dwafns;Z V derr(U n){dmx.n=n;dwafns->ws->er(&dmx);}
EXPORT I DyalogGetInterpreterFunctions(dwa*p){
 if(p)dwafns=p;else R 0;if(dwafns->z<sizeof(S dwa))R 16;R 0;}
Z V err(U n,wchar_t*e){dmx.e=e;throw n;}Z V err(U n){dmx.e=L"";throw n;}
dim4 eshp=dim4(0,(B*)NULL);
std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> strconv;
std::wstring msg;S BX;
typedef std::vector<BX> FRM;typedef std::vector<FRM*> ENV;
typedef std::stack<BX> STK;
S A{I r,f;dim4 s;array v;std::vector<A> nv;
 A(I r,dim4 s,array v):r(r),f(1),s(s),v(v){}
 A():r(0),f(0),s(dim4()),v(array()){}};
S FN{STR nm;I sm;I sd;FN(STR nm,I sm,I sd):nm(nm),sm(sm),sd(sd){}
 FN():nm(""),sm(0),sd(0){}
 virtual array id(dim4 s){err(16);R array();}
 virtual V operator()(A&z,const A&r,ENV&e){err(99);}
 virtual V operator()(A&z,const A&r,D ax,ENV&e){err(99);}
 virtual V operator()(A&z,const A&l,const A&r,ENV&e){err(99);}
 virtual V operator()(A&z,const A&l,const A&r,D ax,ENV&e){err(99);}};
FN MTFN;
S MOP:FN{FN&ll;
 MOP(STR nm,I sm,I sd,FN&ll):FN(nm,sm,sd),ll(ll){}};
S DOP:FN{I fl;I fr;FN&ll;A aa;FN&rr;A ww;
 DOP(STR nm,I sm,I sd,FN&l,FN&r)
  :FN(nm,sm,sd),fl(1),fr(1),ll(l),aa(A()),rr(r),ww(A()){}
 DOP(STR nm,I sm,I sd,A l,FN&r)
  :FN(nm,sm,sd),fl(0),fr(1),ll(MTFN),aa(l),rr(r),ww(A()){}
 DOP(STR nm,I sm,I sd,FN&l,A r)
  :FN(nm,sm,sd),fl(1),fr(0),ll(l),aa(A()),rr(MTFN),ww(r){}};
S MOK{virtual V operator()(FN*&f,FN&l){err(99);}};
S DOK{virtual V operator()(FN*&f,FN&l,FN&r){err(99);}
 virtual V operator()(FN*&f,const A&l,FN&r){err(99);}
 virtual V operator()(FN*&f,FN&l,const A&r){err(99);}};
S BX{A v;union{FN*f;MOK*m;DOK*d;};
 BX(){}BX(FN*f):f(f){}BX(const A&v):v(v){}BX(MOK*m):m(m){}BX(DOK*d):d(d){}};

std::wstring mkstr(const char*s){R strconv.from_bytes(s);}
I scm(FN&f){R f.sm;}I scm(const A&a){R 1;}
I scd(FN&f){R f.sd;}I scd(const A&a){R 1;}
B cnt(dim4 s){B c=1;DO(4,c*=s[i]);R c;}
B cnt(const A&a){B c=1;DO(a.r,c*=a.s[i]);R c;}
B cnt(lp*d){B c=1;DO(RANK(d),c*=SHAPE(d)[i]);R c;}
array scl(D x){R constant(x,dim4(1),f64);}
array scl(I x){R constant(x,dim4(1),s32);}
A scl(array v){R A(0,dim4(1),v);}
dtype mxt(dtype at,dtype bt){if(at==c64||bt==c64)R c64;
 if(at==f64||bt==f64)R f64;
 if(at==s32||bt==s32)R s32;if(at==s16||bt==s16)R s16;
 if(at==b8||bt==b8)R b8;err(16);R f64;}
dtype mxt(const array&a,const array&b){R mxt(a.type(),b.type());}
dtype mxt(dtype at,const A&b){R mxt(at,b.v.type());}
Z array da16(B c,dim4 s,lp*d){std::vector<S16>b(c);
 S8*v=(S8*)DATA(d);DOB(c,b[i]=v[i]);R array(s,b.data());}
Z array da8(B c,dim4 s,lp*d){std::vector<char>b(c);
 U8*v=(U8*)DATA(d);DOB(c,b[i]=1&(v[i/8]>>(7-(i%8))))
 R array(s,b.data());}
V cpad(lp*d,A&a){I t;B c=cnt(a);if(!a.f){d->p=NULL;R;}
 switch(a.v.type()){CS(c64,t=APLZ);
  CS(s32,t=APLI);CS(s16,t=APLSI);CS(b8,t=APLTI);CS(f64,t=APLD);
  default:if(c)err(16);t=APLI;}
 B s[4];DO(a.r,s[a.r-(i+1)]=a.s[i]);dwafns->ws->ga(t,a.r,s,d);
 if(c)a.v.host(DATA(d));}
V cpda(A&a,lp*d){if(d==NULL)R;if(15!=TYPE(d))err(16);if(4<RANK(d))err(16);
 dim4 s(1);DO(RANK(d),s[RANK(d)-(i+1)]=SHAPE(d)[i]);B c=cnt(d);
 switch(ETYPE(d)){
  CS(APLZ,a=A(RANK(d),s,c?array(s,(DZ*)DATA(d)):scl(0)))
  CS(APLI,a=A(RANK(d),s,c?array(s,(I*)DATA(d)):scl(0)))
  CS(APLD,a=A(RANK(d),s,c?array(s,(D*)DATA(d)):scl(0)))
  CS(APLSI,a=A(RANK(d),s,c?array(s,(S16*)DATA(d)):scl(0)))
  CS(APLTI,a=A(RANK(d),s,c?da16(c,s,d):scl(0)))
  CS(APLU8,a=A(RANK(d),s,c?da8(c,s,d):scl(0)))
  default:err(16);}}
EXPORT A*mkarray(lp*d){A*z=new A;cpda(*z,d);R z;}
EXPORT V frea(A*a){delete a;}
EXPORT V exarray(lp*d,A*a){cpad(d,*a);}
EXPORT V afsync(){sync();}
EXPORT Window *w_new(char *k){R new Window(k);}
EXPORT I w_close(Window*w){R w->close();}
EXPORT V w_del(Window*w){delete w;}
EXPORT V w_img(lp*d,Window*w){A a;cpda(a,d);
 w->image(a.v.as(a.r==2?f32:u8));}
EXPORT V w_plot(lp*d,Window*w){A a;cpda(a,d);w->plot(a.v.as(f32));}
EXPORT V w_hist(lp*d,D l,D h,Window*w){A a;cpda(a,d);
 w->hist(a.v.as(u32),l,h);}
EXPORT V loadimg(lp*z,char*p,I c){array a=loadImage(p,c);
 A b(a.numdims(),a.dims(),a.as(s16));cpad(z,b);}
EXPORT V saveimg(lp*im,char*p){A a;cpda(a,im);
 saveImageNative(p,a.v.as(a.v.type()==s32?u16:u8));}
EXPORT V cd_sync(V){sync();}
S fn0_f:FN{MFD;DFD;fn0_f():FN("fnfn0",0,0){};};
fn0_f fn0_c;MF(fn0_f){fn0_c(z,A(),r,e);}

ENV e0(1);I is0=0;
DF(fn0_f){if(is0)R;I fd=0;STK s;e[0]=new FRM(0);
 is0=1;}

